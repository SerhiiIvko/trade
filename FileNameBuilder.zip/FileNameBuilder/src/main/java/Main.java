import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main
{
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        frame.setSize(new Dimension(600, 400));
        frame.getContentPane().add(createContentPanel());
        frame.setVisible(true);
    }

    private static Component createContentPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JButton selectFolderButton = new JButton("Select the folder");
        JTextArea textArea = new JTextArea();
        JButton copyToClipBoardButton = new JButton("Copy to clip board");
        copyToClipBoardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String myString = textArea.getText();
                StringSelection stringSelection = new StringSelection(myString);
                Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                clipboard.setContents(stringSelection, null);
            }
        });
        panel.add(selectFolderButton, BorderLayout.NORTH);
        panel.add(textArea);
        panel.add(copyToClipBoardButton, BorderLayout.SOUTH);
        final File[] directory = {null};
        selectFolderButton.addActionListener(actionEvent -> {
            directory[0] = getDirectory(panel);
            try {
                textArea.setText(addFilesList(directory[0]));
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        return panel;
    }

    private static String addFilesList(File file) throws IOException {
        if (!file.isDirectory())
        {
            throw new IllegalArgumentException(String.format("%s is not a directory", file.getCanonicalPath()));
        }
        String[] list = file.list();
        Pattern pattern = Pattern.compile("(.*)(\\.mp3)");
        StringBuilder sb = new StringBuilder();
        if (list != null) {
            for (String f : list) {
                Matcher matcher = pattern.matcher(f);
                if (matcher.find())
                {
                    sb.append(matcher.group(1)).append("\n");
                }
            }
        }
        return sb.toString();
    }

    private static File getDirectory(JPanel panel) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.showOpenDialog(panel);
        return fileChooser.getCurrentDirectory();
    }
}
